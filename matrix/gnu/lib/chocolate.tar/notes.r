#!/usr/bin/r

library("ggplot2")

# volcano plot
df <- data.frame(height = c(volcano), x = c(row(volcano)), y = c(col(volcano)))
