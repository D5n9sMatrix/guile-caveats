#!/usr/bin/r

parcels(Thurstone)
keys <- c(psych())
keys <- c(psych.misc())

